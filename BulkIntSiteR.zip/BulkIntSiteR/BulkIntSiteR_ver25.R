#Objective:  Small reads integration sites version 2: non-overlapping/hierachy, versatile
#please remove all empty zero bytes files before start

#Try01. Original 20190627
#Try02. 20190627 added plus minus in subset
#Try03-04. Perfect runs
#version2.  
#potential problem: I've reused "n" 
#20220106 edited  
#20231019 ver19 big edit:   fixed 5LTR to 3LTR adjustment +/- 4
#ver20 fix loop problem if ToBLAT file is empty
#ver21 move BLATmerger to local instead of Gdrive
#ver22 fix loop problem if BLAT returned zero


#Step 00. Setup R #PC@work R version 3.2.2
rm(list=ls())
closeAllConnections() 
graphics.off() 
cat("\014") #send CTRL+L to R, clean console
StartSysTime <- Sys.time()
MyWD <- getwd()
setwd(MyWD)
MyBlastnDir <- "/Users/guinmacpro6/"
MyBlatDir <- "/Users/guinmacpro6/" #change as appropriate, remember permission
MyBlatMerger_Dir <- "/Users/guinmacpro6/BLATmergerGUIN"
#REMEMBER TO CHANGE THIS MANUALLY IN LINE 785, 786, 787
library(Biostrings) #PC@work Biostrings_2.38.1
#library(muscle) #PC@work muscle_3.12.0
#sessionInfo()


unlink("./Output/",recursive=TRUE)
dir.create("./Output/")

MyFASTQ <- list.files("RAW_FASTQ")
MyOutputDir <- paste("./Output/Output_",1:length(MyFASTQ),"_",gsub(".fastq","",MyFASTQ),"/",sep="")

#wrapper to process one fastq at a time
for (o in 1:96){#length(MyFASTQ)){
  
  dir.create(MyOutputDir[o])
  print(paste("Processing ",o,": ",MyOutputDir[o],sep=""))
  #############################
  ######### Output ############
  #############################
  
  #DF_Summary1
  MySummary_01_FastqName <- c()
  MySummary_02_FastqLen <- c()
  MySummary_02b_AllHIVLen <- c()
  MySummary_03_EveryReadIDuniq <- c()
  MySummary_04a_Case1_NonHIV_nrow <- c()
  MySummary_04b_Case2_CompleteHIV_nrow <- c()
  MySummary_04c_Case3_LessThanEqual20bpHost_nrow <- c()
  MySummary_04d_Case4a_5LTRsense_nrow <- c()
  MySummary_04e_Case4b_5LTRantisense_nrow <- c()
  MySummary_04f_Case4c_3LTRsense_nrow <- c()
  MySummary_04g_Case4d_3LTRantisense_nrow <- c()
  MySummary_05_HIVjunk <- c()
  
  #DF_Summary2
  MySummary2_00_ReadName <- c()
  MySummary2_01_5or3LTR <- c()
  MySummary2_02_rcYesNo <- c()
  MySummary2_02b_ReadLen <- c()
  MySummary2_03_HIVqstart <- c()
  MySummary2_04_HIVqend <- c()
  MySummary2_05_HIVlen <- c()
  MySummary2_06a_Hostqstart <- c()
  MySummary2_06b_Hostqend <- c()
  MySummary2_07_ToBLAT <- c()
  MyToBLAT_FASTA <- DNAStringSet()
  
  
  #################################################
  
  #Step1. Identify fastq file name
  MyFASTQ <- list.files("RAW_FASTQ")
  
  #################################################
  
  #Process one fastq at a time
  for (x in o:o){
    ################################################
    #Step2. Convert fastq to fasta 
    ################################################
    MyFASTQ_Current <- MyFASTQ[x]
    MySummary_01_FastqName <- append(MySummary_01_FastqName,MyFASTQ_Current)
    MyFASTQ_DNAStringSet <- readDNAStringSet(paste("./RAW_FASTQ/",MyFASTQ_Current,sep=""),format="fastq")
    names(MyFASTQ_DNAStringSet) <- gsub(" ","_",names(MyFASTQ_DNAStringSet))
    names(MyFASTQ_DNAStringSet) <- gsub("/","_",names(MyFASTQ_DNAStringSet))
    names(MyFASTQ_DNAStringSet) <- paste(substring(MyFASTQ_Current,1,5),"_",names(MyFASTQ_DNAStringSet),sep="")
    writeXStringSet(MyFASTQ_DNAStringSet,filepath=paste(MyOutputDir[x],gsub("fastq","fasta",MyFASTQ_Current),sep=""),format="fasta")
    #length(MyFASTQ_DNAStringSet)
    rm(MyFASTQ_DNAStringSet)
    ################################################
    #Step3. Gather global information about FASTQ
    ################################################
    MyFASTA_DNAStringSet_Current <- readDNAStringSet(paste(MyOutputDir[x],gsub("fastq","fasta",MyFASTQ_Current),sep=""),format="fasta")
    MySummary_02_FastqLen <- append(MySummary_02_FastqLen,length(MyFASTA_DNAStringSet_Current))
    MySummary_03_EveryReadIDuniq <- append(MySummary_03_EveryReadIDuniq,length(unique(names(MyFASTA_DNAStringSet_Current)))==length(MyFASTA_DNAStringSet_Current))
    ################################################
    #Step4. MEGA blast run terminal from R.  Throw fasta into local blast against HXB2
    ################################################
    MyBlastCommand <- paste(
      "blastn -query ",paste(MyOutputDir[x],gsub("fastq","fasta",MyFASTQ_Current),sep="")," -db "
      ,MyBlastnDir
      ,"HXB2.fasta -num_alignments 1 -reward 1 -penalty -1 -gapopen 2 -gapextend 1 -out "
      ,MyOutputDir[x]
      ,"Output_Blastn_HXB2MEGA28_tabdelim.txt -outfmt \"6 qseqid qlen sseqid sgi slen qstart qend sstart send evalue bitscore length pident nident btop stitle sstrand\""
      ,sep=""
    )
    system(MyBlastCommand)
    MyBlastresults <- paste(MyOutputDir[x],"Output_Blastn_HXB2MEGA28_tabdelim.txt",sep="")
    MyBlast_DF <- read.delim(MyBlastresults,header=FALSE)
    colnames(MyBlast_DF) <- c("qseqid", "qlen", "sseqid", "sgi", "slen", "qstart", "qend", "sstart", "send", "evalue", "bitscore", "length", "pident", "nident", "btop", "stitle", "sstrand")
    write.csv(MyBlast_DF,paste(MyOutputDir[x],paste(gsub(".fastq","_01BlastnHXB2MEGA28.csv",MyFASTQ_Current),sep=""),sep=""),row.names = FALSE)
    file.remove(paste(MyOutputDir[x],"Output_Blastn_HXB2MEGA28_tabdelim.txt",sep=""))
    #View(MyBlast_DF)
    MyFASTA_HIVonly <- MyFASTA_DNAStringSet_Current[as.character(unique(MyBlast_DF$qseqid))]
    writeXStringSet(MyFASTA_HIVonly,filepath=paste(MyOutputDir[x],gsub(".fastq","_02HIVonly.fasta",MyFASTQ_Current),sep=""))
    ################################################
    #Case 4a.  How many reads had no HIV?
    ################################################
    MyUniqHIVReads_Vector <- as.character(unique(MyBlast_DF$qseqid))
    MyUniqFastqReads_Vector <- as.character(unique(names(MyFASTA_DNAStringSet_Current)))
    MySummary_02b_AllHIVLen <- append(MySummary_02b_AllHIVLen,length(MyUniqHIVReads_Vector))
    MySummary_04a_Case1_NonHIV_nrow <- append(MySummary_04a_Case1_NonHIV_nrow,length(MyFASTA_DNAStringSet_Current[!(MyUniqFastqReads_Vector %in% MyUniqHIVReads_Vector)]))
    ################################################
    #Step 4b.  How many reads had 100% HIV? Remove them from DF
    ################################################
    MyBlast_DF_4b_AllHIV <- subset(MyBlast_DF,(MyBlast_DF$qstart==1 & MyBlast_DF$qend==qlen)|(MyBlast_DF$qstart==qlen & MyBlast_DF$qend==1))
    #View(MyBlast_DF_4b_AllHIV)
    My4b_AllHIV_Vector <- as.character(unique(MyBlast_DF_4b_AllHIV$qseqid))
    MySummary_04b_Case2_CompleteHIV_nrow <- append(MySummary_04b_Case2_CompleteHIV_nrow,length(My4b_AllHIV_Vector))
    #Remove
    MyBlast_DF_4b <- subset(MyBlast_DF,!MyBlast_DF$qseqid %in% My4b_AllHIV_Vector)
    #View(MyBlast_DF_4b)
    ################################################
    #Step 4c.  How many reads contain host but host <=20bp
    ################################################
    MyBlast_DF_4c_LessThan20 <- subset(MyBlast_DF_4b,(MyBlast_DF_4b$qlen-MyBlast_DF_4b$length)<=20)
    My4c_LessThan20_Vector <- as.character(unique(MyBlast_DF_4c_LessThan20$qseqid))
    MySummary_04c_Case3_LessThanEqual20bpHost_nrow <- append(MySummary_04c_Case3_LessThanEqual20bpHost_nrow,length(My4c_LessThan20_Vector))
    #Remove
    MyBlast_DF_4c <- subset(MyBlast_DF_4b,!MyBlast_DF_4b$qseqid %in% My4c_LessThan20_Vector)
    #View(MyBlast_DF_4c)
    ################################################
    #Step 4d.  CASE #1.  5LTR chemistry; small read is on the sense strand
    ################################################
    MyBlast_DF_4d_5LTRsense <- subset(MyBlast_DF_4c,(MyBlast_DF_4c$sstart==1 | MyBlast_DF_4c$sstart==9086) & MyBlast_DF_4c$qend==MyBlast_DF_4c$qlen & MyBlast_DF_4c$sstrand=="plus")
    #order df so that the longest HIV mapped is listed first, in case if there are duplicated mappings; 1 takes priority over 9719
    MyBlast_DF_4d_5LTRsense <- MyBlast_DF_4d_5LTRsense[order(MyBlast_DF_4d_5LTRsense$qseqid,-MyBlast_DF_4d_5LTRsense$length,MyBlast_DF_4d_5LTRsense$sstart),]
    #View(MyBlast_DF_4d_5LTRsense)
    if (nrow(MyBlast_DF_4d_5LTRsense)>1){
      #extract first in order
      MyDup <- c("OK")
      for (n in 2:nrow(MyBlast_DF_4d_5LTRsense)){
        if (MyBlast_DF_4d_5LTRsense$qseqid[n]==MyBlast_DF_4d_5LTRsense$qseqid[n-1]){
          MyDup <- append(MyDup,"Duplicate")
        } else {
          MyDup <- append(MyDup,"OK")
        }
      }
      MyDup_Index <- which(MyDup=="OK")
      MyBlast_DF_4d_5LTRsense <- MyBlast_DF_4d_5LTRsense[MyDup_Index,]
      #View(MyBlast_DF_4d_5LTRsense)
    } else {
      #do nothing
    }
    #count
    My4d_5LTRsense_vector <- as.character(unique(MyBlast_DF_4d_5LTRsense$qseqid))
    MySummary_04d_Case4a_5LTRsense_nrow <- append(MySummary_04d_Case4a_5LTRsense_nrow,length(My4d_5LTRsense_vector))
    if(nrow(MyBlast_DF_4d_5LTRsense)>0){
      for (a in 1:nrow(MyBlast_DF_4d_5LTRsense)){
        MyReadName <- as.character(MyBlast_DF_4d_5LTRsense$qseqid[a])
        MySummary2_00_ReadName <- append(MySummary2_00_ReadName,MyReadName)
        MySummary2_01_5or3LTR <- append(MySummary2_01_5or3LTR,"5LTR")
        MySummary2_02_rcYesNo <- append(MySummary2_02_rcYesNo,"sense")
        MySummary2_02b_ReadLen <- append(MySummary2_02b_ReadLen,as.numeric(MyBlast_DF_4d_5LTRsense$qlen[a]))
        MySummary2_03_HIVqstart <- append(MySummary2_03_HIVqstart,as.numeric(MyBlast_DF_4d_5LTRsense$qstart[a]))
        MySummary2_04_HIVqend <- append(MySummary2_04_HIVqend,as.numeric(MyBlast_DF_4d_5LTRsense$qend[a]))
        MySummary2_05_HIVlen <- append(MySummary2_05_HIVlen,as.numeric(MyBlast_DF_4d_5LTRsense$length[a]))
        #Host portion must be directly adjecent to HXB2 1 or 9719
        MyHost_qstart <- 1
        MyHost_qend <- as.numeric(MyBlast_DF_4d_5LTRsense$qstart[a])-1
        MySummary2_06a_Hostqstart <- append(MySummary2_06a_Hostqstart,MyHost_qstart)
        MySummary2_06b_Hostqend <- append(MySummary2_06b_Hostqend,MyHost_qend)
        MyToBlat <- subseq(MyFASTA_DNAStringSet_Current[MyReadName],start=MyHost_qstart,end=MyHost_qend)
        MySummary2_07_ToBLAT <- append(MySummary2_07_ToBLAT,as.character(MyToBlat))
        MyToBLAT_FASTA <- append(MyToBLAT_FASTA,MyToBlat)
      }
    } else {
      #do nothing
    }
    #Remove
    MyBlast_DF_4d <- subset(MyBlast_DF_4c,!MyBlast_DF_4c$qseqid %in% My4d_5LTRsense_vector)
    #View(MyBlast_DF_4d)
    ###############################################################
    #Step 4e.  Case #2. 5LTR chemistry; small read is on the antisense strand
    ###############################################################
    MyBlast_DF_4e_5LTRantisense <- subset(MyBlast_DF_4d,(MyBlast_DF_4d$send==1 | MyBlast_DF_4d$send==9086)&MyBlast_DF_4d$qstart==1 & MyBlast_DF_4d$sstrand=="minus")
    #order df so that the longest HIV mapped is listed first, in case if there are duplicated mappings; 1 takes priority over 9719
    MyBlast_DF_4e_5LTRantisense <- MyBlast_DF_4e_5LTRantisense[order(MyBlast_DF_4e_5LTRantisense$qseqid,-MyBlast_DF_4e_5LTRantisense$length,MyBlast_DF_4e_5LTRantisense$send),]
    #View(MyBlast_DF_4e_5LTRantisense)
    #extract first in order
    if (nrow(MyBlast_DF_4e_5LTRantisense)>1){
      MyDup <- c("OK")
      for (n in 2:nrow(MyBlast_DF_4e_5LTRantisense)){
        if (MyBlast_DF_4e_5LTRantisense$qseqid[n]==MyBlast_DF_4e_5LTRantisense$qseqid[n-1]){
          MyDup <- append(MyDup,"Duplicate")
        } else {
          MyDup <- append(MyDup,"OK")
        }
      }
      MyDup_Index <- which(MyDup=="OK")
      MyBlast_DF_4e_5LTRantisense <- MyBlast_DF_4e_5LTRantisense[MyDup_Index,]
    } else {
      #do nothing
    }
    #View(MyBlast_DF_4e_5LTRantisense)
    #count
    My4e_5LTRantisense_vector <- as.character(unique(MyBlast_DF_4e_5LTRantisense$qseqid))
    MySummary_04e_Case4b_5LTRantisense_nrow <- append(MySummary_04e_Case4b_5LTRantisense_nrow,length(My4e_5LTRantisense_vector))
    if(nrow(MyBlast_DF_4e_5LTRantisense)>0){
      for (a in 1:nrow(MyBlast_DF_4e_5LTRantisense)){
        MyReadName <- as.character(MyBlast_DF_4e_5LTRantisense$qseqid[a])
        MySummary2_00_ReadName <- append(MySummary2_00_ReadName,MyReadName)
        MySummary2_01_5or3LTR <- append(MySummary2_01_5or3LTR,"5LTR")
        MySummary2_02_rcYesNo <- append(MySummary2_02_rcYesNo,"antisense")
        MySummary2_02b_ReadLen <- append(MySummary2_02b_ReadLen,as.numeric(MyBlast_DF_4e_5LTRantisense$qlen[a]))
        MySummary2_03_HIVqstart <- append(MySummary2_03_HIVqstart,as.numeric(MyBlast_DF_4e_5LTRantisense$qstart[a]))
        MySummary2_04_HIVqend <- append(MySummary2_04_HIVqend,as.numeric(MyBlast_DF_4e_5LTRantisense$qend[a]))
        MySummary2_05_HIVlen <- append(MySummary2_05_HIVlen,as.numeric(MyBlast_DF_4e_5LTRantisense$length[a]))
        #Host portion must be directly adjecent to HXB2 1 or 9719
        MyHost_qstart <- as.numeric(MyBlast_DF_4e_5LTRantisense$qend[a])+1
        MyHost_qend <- as.numeric(MyBlast_DF_4e_5LTRantisense$qlen[a])
        MySummary2_06a_Hostqstart <- append(MySummary2_06a_Hostqstart,MyHost_qstart)
        MySummary2_06b_Hostqend <- append(MySummary2_06b_Hostqend,MyHost_qend)
        MyToBlat <- reverseComplement(subseq(MyFASTA_HIVonly[MyReadName],start=MyHost_qstart,end=MyHost_qend))
        MySummary2_07_ToBLAT <- append(MySummary2_07_ToBLAT,as.character(MyToBlat))
        MyToBLAT_FASTA <- append(MyToBLAT_FASTA,MyToBlat)
      }
    } else {
      #do nothing
    }
    #Remove
    MyBlast_DF_4e <- subset(MyBlast_DF_4d,!MyBlast_DF_4d$qseqid %in% My4e_5LTRantisense_vector)
    #View(MyBlast_DF_4e)
    ############################################################
    # Step 4f.  Case #3.  3LTR chemistry; small read is on the sense strand
    ############################################################
    MyBlast_DF_4f_3LTRsense <- subset(MyBlast_DF_4e,(MyBlast_DF_4e$send==9719 | MyBlast_DF_4e$send==634)&MyBlast_DF_4e$qstart==1 & MyBlast_DF_4e$sstrand=="plus")
    #order df so that the longest HIV mapped is listed first, in case if there are duplicated mappings; 9719 takes priority over 634
    MyBlast_DF_4f_3LTRsense <- MyBlast_DF_4f_3LTRsense[order(MyBlast_DF_4f_3LTRsense$qseqid,-MyBlast_DF_4f_3LTRsense$length,-MyBlast_DF_4f_3LTRsense$send),]
    #View(MyBlast_DF_4f_3LTRsense)
    if (nrow(MyBlast_DF_4f_3LTRsense)>1){
      #extract first in order
      MyDup <- c("OK")
      for (n in 2:nrow(MyBlast_DF_4f_3LTRsense)){
        if (MyBlast_DF_4f_3LTRsense$qseqid[n]==MyBlast_DF_4f_3LTRsense$qseqid[n-1]){
          MyDup <- append(MyDup,"Duplicate")
        } else {
          MyDup <- append(MyDup,"OK")
        }
      }
      MyDup_Index <- which(MyDup=="OK")
      MyBlast_DF_4f_3LTRsense <- MyBlast_DF_4f_3LTRsense[MyDup_Index,]
      #View(MyBlast_DF_4f_3LTRsense)
    } else {
      #do nothing
    }
    #count
    My4f_3LTRsense_vector <- as.character(unique(MyBlast_DF_4f_3LTRsense$qseqid))
    MySummary_04f_Case4c_3LTRsense_nrow <- append(MySummary_04f_Case4c_3LTRsense_nrow,length(My4f_3LTRsense_vector))
    if (nrow(MyBlast_DF_4f_3LTRsense)>0){
      for (a in 1:nrow(MyBlast_DF_4f_3LTRsense)){
        MyReadName <- as.character(MyBlast_DF_4f_3LTRsense$qseqid[a])
        MySummary2_00_ReadName <- append(MySummary2_00_ReadName,MyReadName)
        MySummary2_01_5or3LTR <- append(MySummary2_01_5or3LTR,"3LTR")
        MySummary2_02_rcYesNo <- append(MySummary2_02_rcYesNo,"sense")
        MySummary2_02b_ReadLen <- append(MySummary2_02b_ReadLen,as.numeric(MyBlast_DF_4f_3LTRsense$qlen[a]))
        MySummary2_03_HIVqstart <- append(MySummary2_03_HIVqstart,as.numeric(MyBlast_DF_4f_3LTRsense$qstart[a]))
        MySummary2_04_HIVqend <- append(MySummary2_04_HIVqend,as.numeric(MyBlast_DF_4f_3LTRsense$qend[a]))
        MySummary2_05_HIVlen <- append(MySummary2_05_HIVlen,as.numeric(MyBlast_DF_4f_3LTRsense$length[a]))
        #Host portion must be directly adjecent to HXB2 1 or 9719
        MyHost_qstart <- as.numeric(MyBlast_DF_4f_3LTRsense$qend[a])+1
        MyHost_qend <- as.numeric(MyBlast_DF_4f_3LTRsense$qlen[a])
        MySummary2_06a_Hostqstart <- append(MySummary2_06a_Hostqstart,MyHost_qstart)
        MySummary2_06b_Hostqend <- append(MySummary2_06b_Hostqend,MyHost_qend)
        MyToBlat <- subseq(MyFASTA_HIVonly[MyReadName],start=MyHost_qstart,end=MyHost_qend)
        MySummary2_07_ToBLAT <- append(MySummary2_07_ToBLAT,as.character(MyToBlat))
        MyToBLAT_FASTA <- append(MyToBLAT_FASTA,MyToBlat)
      }
    } else {
      #do nothing
    }
    #Remove
    MyBlast_DF_4f <- subset(MyBlast_DF_4e,!MyBlast_DF_4e$qseqid %in% My4f_3LTRsense_vector)
    #View(MyBlast_DF_4f)
    ############################################################
    # Step 4g. Case #4.  3LTR chemistry; small read is on the antisense strand
    ############################################################
    MyBlast_DF_4g_3LTRantisense <- subset(MyBlast_DF_4f,(MyBlast_DF_4f$sstart==9719 | MyBlast_DF_4f$sstart==634) & MyBlast_DF_4f$qend==MyBlast_DF_4f$qlen & MyBlast_DF_4f$sstrand=="minus")
    #order df so that the longest HIV mapped is listed first, in case if there are duplicated mappings; 9719 takes priority over 634
    MyBlast_DF_4g_3LTRantisense <- MyBlast_DF_4g_3LTRantisense[order(MyBlast_DF_4g_3LTRantisense$qseqid,-MyBlast_DF_4g_3LTRantisense$length,-MyBlast_DF_4g_3LTRantisense$sstart),]
    #View(MyBlast_DF_4g_3LTRantisense)
    if (nrow(MyBlast_DF_4g_3LTRantisense)>1){
      #extract first in order
      MyDup <- c("OK")
      for (n in 2:nrow(MyBlast_DF_4g_3LTRantisense)){
        if (MyBlast_DF_4g_3LTRantisense$qseqid[n]==MyBlast_DF_4g_3LTRantisense$qseqid[n-1]){
          MyDup <- append(MyDup,"Duplicate")
        } else {
          MyDup <- append(MyDup,"OK")
        }
      }
      MyDup_Index <- which(MyDup=="OK")
      MyBlast_DF_4g_3LTRantisense <- MyBlast_DF_4g_3LTRantisense[MyDup_Index,]
      #View(MyBlast_DF_4g_3LTRantisense)
    } else {
      #do nothing
    }
    #count
    My4g_3LTRantisense_vector <- as.character(unique(MyBlast_DF_4g_3LTRantisense$qseqid))
    MySummary_04g_Case4d_3LTRantisense_nrow <- append(MySummary_04g_Case4d_3LTRantisense_nrow,length(My4g_3LTRantisense_vector))
    if (nrow(MyBlast_DF_4g_3LTRantisense)>0){
      for (a in 1:nrow(MyBlast_DF_4g_3LTRantisense)){
        MyReadName <- as.character(MyBlast_DF_4g_3LTRantisense$qseqid[a])
        MySummary2_00_ReadName <- append(MySummary2_00_ReadName,MyReadName)
        MySummary2_01_5or3LTR <- append(MySummary2_01_5or3LTR,"3LTR")
        MySummary2_02_rcYesNo <- append(MySummary2_02_rcYesNo,"antisense")
        MySummary2_02b_ReadLen <- append(MySummary2_02b_ReadLen,as.numeric(MyBlast_DF_4g_3LTRantisense$qlen[a]))
        MySummary2_03_HIVqstart <- append(MySummary2_03_HIVqstart,as.numeric(MyBlast_DF_4g_3LTRantisense$qstart[a]))
        MySummary2_04_HIVqend <- append(MySummary2_04_HIVqend,as.numeric(MyBlast_DF_4g_3LTRantisense$qend[a]))
        MySummary2_05_HIVlen <- append(MySummary2_05_HIVlen,as.numeric(MyBlast_DF_4g_3LTRantisense$length[a]))
        #Host portion must be directly adjecent to HXB2 1 or 9719
        MyHost_qstart <- 1
        MyHost_qend <- as.numeric(MyBlast_DF_4g_3LTRantisense$qstart[a])-1
        MySummary2_06a_Hostqstart <- append(MySummary2_06a_Hostqstart,MyHost_qstart)
        MySummary2_06b_Hostqend <- append(MySummary2_06b_Hostqend,MyHost_qend)
        MyToBlat <- reverseComplement(subseq(MyFASTA_HIVonly[MyReadName],start=MyHost_qstart,end=MyHost_qend))
        MySummary2_07_ToBLAT <- append(MySummary2_07_ToBLAT,as.character(MyToBlat))
        MyToBLAT_FASTA <- append(MyToBLAT_FASTA,MyToBlat)
      }
    } else {
      #do nothing
    }
    #Remove
    MyBlast_DF_4g <- subset(MyBlast_DF_4f,!MyBlast_DF_4f$qseqid %in% My4g_3LTRantisense_vector)
    #View(MyBlast_DF_4g)
    ################################################
    #Step5. Leftover
    ################################################
    My5_HIVjunk_vector <- as.character(unique(MyBlast_DF_4g$qseqid))
    MySummary_05_HIVjunk <- append(MySummary_05_HIVjunk,length(My5_HIVjunk_vector))
    write.csv(MyBlast_DF_4g,paste(MyOutputDir[x],paste(gsub(".fastq","_03HIVjunk.csv",MyFASTQ_Current),sep=""),sep=""),row.names = FALSE)
  }
  
  
  
  #################################################
  MySummary_DF <- as.data.frame(cbind(MySummary_01_FastqName
                                      ,MySummary_02_FastqLen
                                      ,MySummary_02b_AllHIVLen
                                      ,MySummary_03_EveryReadIDuniq
                                      ,MySummary_04a_Case1_NonHIV_nrow
                                      ,MySummary_04b_Case2_CompleteHIV_nrow
                                      ,MySummary_04c_Case3_LessThanEqual20bpHost_nrow
                                      ,MySummary_04d_Case4a_5LTRsense_nrow
                                      ,MySummary_04e_Case4b_5LTRantisense_nrow
                                      ,MySummary_04f_Case4c_3LTRsense_nrow
                                      ,MySummary_04g_Case4d_3LTRantisense_nrow
                                      ,MySummary_05_HIVjunk
  ))
  write.csv(MySummary_DF,file=paste(MyOutputDir[o],"Output01_MySummaryDF_Count.csv",sep=""),row.names = FALSE)
  #################################################
  MySummary2_08_BLATlen <- as.numeric(nchar(MySummary2_07_ToBLAT))
  MySummary2_DF <- as.data.frame(cbind(
    MySummary2_00_ReadName
    ,MySummary2_01_5or3LTR
    ,MySummary2_02_rcYesNo
    ,MySummary2_02b_ReadLen
    ,MySummary2_03_HIVqstart
    ,MySummary2_04_HIVqend
    ,MySummary2_05_HIVlen
    ,MySummary2_06a_Hostqstart
    ,MySummary2_06b_Hostqend
    ,MySummary2_07_ToBLAT
    ,MySummary2_08_BLATlen
  ))
  write.csv(MySummary2_DF,file=paste(MyOutputDir[o],"Output02_MySummaryDF2_BlastHIVonly.csv",sep=""),row.names = FALSE)
  writeXStringSet(MyToBLAT_FASTA,filepath=paste(MyOutputDir[o],"Output03_ToBLAT.fasta",sep=""))
  #View(MySummary2_DF)
  #######################
  
  #Bar Plot Summary
  MySummary_DF_transpose <- t(MySummary_DF)
  MySummary_DF_transpose <- cbind(MySummary_DF_transpose,
                                  rownames(MySummary_DF_transpose)
  )
  colnames(MySummary_DF_transpose) <- c(substr(MySummary_DF_transpose[1,1:(ncol(MySummary_DF_transpose)-1)],1,5),"Group")
  #View(MySummary_DF)
  pdf(file=paste(MyOutputDir[o],"Output04_piecharts.pdf",sep=""))
  for (c in 1:(ncol(MySummary_DF_transpose)-1)){
    MySlices <- as.numeric(MySummary_DF_transpose[5:12,c])
    MyLabels <- c("NonHIV","100%HIV","Host<=20bp","5LTRsense","5LTRantisense","3LTRsense","3LTRantisense","HIVjunk")
    MyColor <- c("grey","grey","grey","red","pink","blue","lightblue","grey")
    #rainbow(length(MyLabels)) #cm.colors(length(MyLabels))#heat.colors(length(MyLabels))
    pie(MySlices,label=MyLabels,main=colnames(MySummary_DF_transpose)[c],cex=0.7,clockwise=TRUE,init.angle = 90,col=MyColor)
    #legend(10,10,legend=MyLabels,fill=MyColor)
  }
  dev.off()
  #closeAllConnections() 
  #graphics.off() 
  
  
#### if ToBLAT is zero ###
if (length(MyToBLAT_FASTA)==0){
  ##### Print error if nothing made to BLAT ###
  #MyToBLAT_count <- readDNAStringSet(paste(MyOutputDir[o],"Output03_ToBLAT.fasta",sep=""))
  #if (length(MyToBLAT_count)==0){
  print(paste(MyFASTQ[o],"Error:  No seq made it to BLAT; check for other errors"))
} else {
      ############ BLAT ##############
  
  #Step1. Copy ToBLAT fasta to Users/guin/
  file.copy(paste(MyOutputDir[o],"Output03_ToBLAT.fasta",sep=""),MyBlatDir)
  setwd(MyBlatDir)
  system("./blat hg38.2bit Output03_ToBLAT.fasta -out=blast8 Output05_BLAT.blast8")
  #### HERE ####
  file.copy(paste(MyBlatDir,"Output05_BLAT.blast8",sep=""),paste(MyWD,paste(gsub("\\./","/",MyOutputDir[o]),"Output05_BLAT.blast8",sep=""),sep=""))
  file.remove(paste(MyBlatDir,"Output03_ToBLAT.fasta",sep=""))
  file.remove(paste(MyBlatDir,"Output05_BLAT.blast8",sep=""))
  setwd(MyWD)
  
  #Check if BLAT output is zero
  if (file.size(paste(MyOutputDir[o],"Output05_BLAT.blast8",sep=""))==0){
    print ("BLAT returned no matches")
  } else {
    ########### BLAT merger ###############
    
    #Read in the BLAT raw output
    MyBlat_Ouptut_DF <- read.delim(paste(MyOutputDir[o],"Output05_BLAT.blast8",sep=""),header=FALSE)
    colnames(MyBlat_Ouptut_DF) <- c("QUERY","CHRO","IDENTITY","SPAN","MISMATCHES","GAPOPEN","QSTART","QEND","TSTART","TEND","EVALUE","BITSCORE")
    #Add 5LTR 3LTR information
    MyBlat_Ouptut_DF2 <- merge(MyBlat_Ouptut_DF
                               #,MySummary2_DF[,c("MGHFastaID","WhichEnd","MyBLAT_len")]
                               ,MySummary2_DF[,c("MySummary2_00_ReadName","MySummary2_01_5or3LTR","MySummary2_08_BLATlen")]
                               ,by.x="QUERY"
                               #,by.y="MGHFastaID"
                               ,by.y="MySummary2_00_ReadName"
                               ,all.x = TRUE
                               ,all.y = FALSE)
    colnames(MyBlat_Ouptut_DF2)[(ncol(MyBlat_Ouptut_DF2)-1):ncol(MyBlat_Ouptut_DF2)] <- c("WhichEnd","MyBLAT_len")
    MyBlat_Ouptut_DF2$WhichEnd <- gsub("5LTR","5Lenti",MyBlat_Ouptut_DF2$WhichEnd)
    MyBlat_Ouptut_DF2$WhichEnd <- gsub("3LTR","3Lenti",MyBlat_Ouptut_DF2$WhichEnd)
    #MyBlat_Ouptut_DF2$MyBLAT_len <- as.numeric(MyBlat_Ouptut_DF2$MyBLAT_len) #incorrect conversion broke all in ver05
    write.csv(MyBlat_Ouptut_DF2,file=paste(MyOutputDir[o],"Output06_BLAT2.csv",sep=""))
    
    
    #View(MyBlat_Ouptut_DF2)
    #SAVE HERE 20191225#
    
    #Step2. Run BLAT merger
    MyWD_BlatMerger <- MyBlatMerger_Dir
    setwd(MyWD_BlatMerger)
    source(paste(MyBlatMerger_Dir,"/R_BLATmerge_ver10_fix3LTRtstart.R",sep=""))
    
    
    
    
    
    #Step3. Copy output back to SEQ dir
    MyBlatDir <- "./Output_BLATmerger/"
    #file.copy("./BLAT_HTML",MyBlatDir,recursive=TRUE)
    #unlink("./BLAT_HTML",recursive=TRUE)
    ### Getting the right dir
    MyFASTQ <- list.files(paste(MyWD,"/RAW_FASTQ/",sep=""))
    MyOutputDir <- paste("./Output/Output_",1:length(MyFASTQ),"_",gsub(".fastq","",MyFASTQ),"/",sep="")
    # add to Blat merge to not remove o
    #######
    file.copy(MyBlatDir,paste(MyWD,gsub("\\./","/",MyOutputDir[o]),sep=""),recursive=TRUE)
    unlink(MyBlatDir,recursive=TRUE)
    setwd(MyWD)
    
    
    ##############################
    # Merge all db so far
    ##############################
    
    MyBlat <- read.csv(paste(MyOutputDir[o],"Output_BLATmerger/03_BLAT_HTML_TopScore_NCBIRefGenes.csv",sep="")) #nrow 29961
    MySummary2_DF <- read.csv(paste(MyOutputDir[o],"Output02_MySummaryDF2_BlastHIVonly.csv",sep="")) #nrow #43316
    MyFinal_DB <- merge(MySummary2_DF
                        ,MyBlat
                        ,by.x="MySummary2_00_ReadName"
                        ,by.y="QUERY"
                        ,all.x=TRUE
                        ,all.y=TRUE)
    #View(MyFinal_DB) #nrow 43316
    #View(MyBlat)
    
    ###########################################
    # Adjust 5 3 chr coordinates ##############
    ###########################################
    
    My5Verdict <- c()
    My3Verdict <- c()
    for (i in 1:nrow(MyFinal_DB)){
      if (is.na(MyFinal_DB$QSTART[i])) {
        My5Verdict <- append(My5Verdict,NA)
        My3Verdict <- append(My3Verdict,NA)
      } else {
        if (MyFinal_DB$WhichEnd[i]=="5Lenti" & MyFinal_DB$STRAND[i]=="+"){
          My5Verdict <- append(My5Verdict,paste(MyFinal_DB$CHRO[i],"_",MyFinal_DB$TEND[i],"_",MyFinal_DB$STRAND[i],"_",MyFinal_DB$MyMatchResult_Name2[i],sep=""))
          My3Verdict <- append(My3Verdict,paste(MyFinal_DB$CHRO[i],"_",MyFinal_DB$TEND[i]-4,"_",MyFinal_DB$STRAND[i],"_",MyFinal_DB$MyMatchResult_Name2[i],sep=""))
        } else if (MyFinal_DB$WhichEnd[i]=="5Lenti" & MyFinal_DB$STRAND[i]=="-") {
          My5Verdict <- append(My5Verdict,paste(MyFinal_DB$CHRO[i],"_",MyFinal_DB$TEND[i],"_",MyFinal_DB$STRAND[i],"_",MyFinal_DB$MyMatchResult_Name2[i],sep=""))
          My3Verdict <- append(My3Verdict,paste(MyFinal_DB$CHRO[i],"_",MyFinal_DB$TEND[i]+4,"_",MyFinal_DB$STRAND[i],"_",MyFinal_DB$MyMatchResult_Name2[i],sep=""))
        } else if (MyFinal_DB$WhichEnd[i]=="3Lenti" & MyFinal_DB$STRAND[i]=="+"){
          My5Verdict <- append(My5Verdict,paste(MyFinal_DB$CHRO[i],"_",MyFinal_DB$TSTART[i]+4,"_",MyFinal_DB$STRAND[i],"_",MyFinal_DB$MyMatchResult_Name2[i],sep=""))
          My3Verdict <- append(My3Verdict,paste(MyFinal_DB$CHRO[i],"_",MyFinal_DB$TSTART[i],"_",MyFinal_DB$STRAND[i],"_",MyFinal_DB$MyMatchResult_Name2[i],sep=""))
        } else if (MyFinal_DB$WhichEnd[i]=="3Lenti" & MyFinal_DB$STRAND[i]=="-") {
          My5Verdict <- append(My5Verdict,paste(MyFinal_DB$CHRO[i],"_",MyFinal_DB$TSTART[i]-4,"_",MyFinal_DB$STRAND[i],"_",MyFinal_DB$MyMatchResult_Name2[i],sep=""))
          My3Verdict <- append(My3Verdict,paste(MyFinal_DB$CHRO[i],"_",MyFinal_DB$TSTART[i],"_",MyFinal_DB$STRAND[i],"_",MyFinal_DB$MyMatchResult_Name2[i],sep=""))
        } else {
          My5Verdict <- append(My5Verdict,NA)
          My3Verdict <- append(My3Verdict,NA)
        }
      }
    }
    
    MyFinal_DB <- cbind(MyFinal_DB
                        ,My5Verdict
                        ,My3Verdict)
    
    write.csv(MyFinal_DB,file=paste(MyOutputDir[o],"Output07a_MyFinalDB.csv",sep=""))
    
    ########################################
    
    #Finally, grab summary info
    
    MyFinal_DB <- read.csv(paste(MyOutputDir[o],"Output07a_MyFinalDB.csv",sep=""))
    MySeqID <- substr(MyFinal_DB$MySummary2_00_ReadName,1,5)
    MyIntSiteNotNA <- !is.na(MyFinal_DB$My3Verdict)
    MyFinal_DB <- cbind(MyFinal_DB
                        ,MySeqID
                        ,MyIntSiteNotNA)
    #View(MyFinal_DB)
    MyFinal_DB_Clean <- subset(MyFinal_DB,MyFinal_DB$My3Verdict!="NA")
    #View(MyFinal_DB_Clean)
    MyQC <- gsub("FALSE","FailedQC",MyFinal_DB_Clean$QSTART==1 & MyFinal_DB_Clean$QEND==MyFinal_DB_Clean$MySummary2_08_BLATlen)
    #20191226 Can consider relaxing this
    MyQC <- gsub("TRUE","PassedQC",MyQC)
    MyFinal_DB_Clean <- cbind(MyFinal_DB_Clean,MyQC)
    write.csv(MyFinal_DB_Clean,file=paste(MyOutputDir[o],"Output07b_MyFinalDB_WithIntSiteOnly.csv",sep=""),row.names = FALSE)
    
    MyFinal_DB_Table <- MyFinal_DB[,c("MySeqID","MySummary2_01_5or3LTR","MySummary2_02_rcYesNo","MyIntSiteNotNA")]
    MyFinal_DB_TableSummary <- as.data.frame(table(MyFinal_DB_Table))
    #View(MyFinal_DB_TableSummary)
    
    MySummary_06_MySeqID <- c()
    MySummary_06a_5LTRsense_IntSite_nrow <- c()
    MySummary_06b_5LTRsense_NA_nrow <- c()
    MySummary_07a_5LTRantisense_IntSite_nrow <- c()
    MySummary_07b_5LTRantisense_NA_nrow <- c()
    MySummary_08a_3LTRsense_IntSite_nrow <- c()
    MySummary_08b_3LTRsense_NA_nrow <- c()
    MySummary_09a_3LTRantisense_IntSite_nrow <- c()
    MySummary_09b_3LTRantisense_NA_nrow <- c()
    
    for (k in 1:length(unique(MySeqID))){
      MySummary_06_MySeqID <- append(MySummary_06_MySeqID,unique(MySeqID)[k])
      #5LTR
      #MyFinal_DB_TableSummary_5LTRsense 
      MyFinal_DB_TableSummary_current <- subset(MyFinal_DB_TableSummary,MyFinal_DB_TableSummary$MySeqID==unique(MySeqID)[k] & MyFinal_DB_TableSummary$MySummary2_01_5or3LTR=="5LTR" & MyFinal_DB_TableSummary$MySummary2_02_rcYesNo =="sense" & MyFinal_DB_TableSummary$MyIntSiteNotNA==TRUE)
      if ( nrow(MyFinal_DB_TableSummary_current)==0 ) { 
        MyValue <- 0
      } else {
        MyValue <- as.numeric(MyFinal_DB_TableSummary_current$Freq)
      }
      MySummary_06a_5LTRsense_IntSite_nrow <- append(MySummary_06a_5LTRsense_IntSite_nrow,MyValue)
      #MyFinal_DB_TableSummary_5LTRsense_NA 
      MyFinal_DB_TableSummary_current <- subset(MyFinal_DB_TableSummary,MyFinal_DB_TableSummary$MySeqID==unique(MySeqID)[k] & MyFinal_DB_TableSummary$MySummary2_01_5or3LTR=="5LTR" & MyFinal_DB_TableSummary$MySummary2_02_rcYesNo =="sense" & MyFinal_DB_TableSummary$MyIntSiteNotNA==FALSE)
      if ( nrow(MyFinal_DB_TableSummary_current)==0 ) { 
        MyValue <- 0
      } else {
        MyValue <- as.numeric(MyFinal_DB_TableSummary_current$Freq)
      }
      MySummary_06b_5LTRsense_NA_nrow <- append(MySummary_06b_5LTRsense_NA_nrow,MyValue)
      #MyFinal_DB_TableSummary_5LTRantisense 
      MyFinal_DB_TableSummary_current <- subset(MyFinal_DB_TableSummary,MyFinal_DB_TableSummary$MySeqID==unique(MySeqID)[k] & MyFinal_DB_TableSummary$MySummary2_01_5or3LTR=="5LTR" & MyFinal_DB_TableSummary$MySummary2_02_rcYesNo =="antisense" & MyFinal_DB_TableSummary$MyIntSiteNotNA==TRUE)
      if ( nrow(MyFinal_DB_TableSummary_current)==0 ) { 
        MyValue <- 0
      } else {
        MyValue <- as.numeric(MyFinal_DB_TableSummary_current$Freq)
      }
      MySummary_07a_5LTRantisense_IntSite_nrow <- append(MySummary_07a_5LTRantisense_IntSite_nrow,MyValue)
      #MyFinal_DB_TableSummary_5LTRantisense_NA 
      MyFinal_DB_TableSummary_current <- subset(MyFinal_DB_TableSummary,MyFinal_DB_TableSummary$MySeqID==unique(MySeqID)[k] & MyFinal_DB_TableSummary$MySummary2_01_5or3LTR=="5LTR" & MyFinal_DB_TableSummary$MySummary2_02_rcYesNo =="antisense" & MyFinal_DB_TableSummary$MyIntSiteNotNA==FALSE)
      if ( nrow(MyFinal_DB_TableSummary_current)==0 ) { 
        MyValue <- 0
      } else {
        MyValue <- as.numeric(MyFinal_DB_TableSummary_current$Freq)
      }
      MySummary_07b_5LTRantisense_NA_nrow <- append(MySummary_07b_5LTRantisense_NA_nrow,MyValue)
      #3LTR
      #MyFinal_DB_TableSummary_3LTRsense 
      MyFinal_DB_TableSummary_current <- subset(MyFinal_DB_TableSummary,MyFinal_DB_TableSummary$MySeqID==unique(MySeqID)[k] & MyFinal_DB_TableSummary$MySummary2_01_5or3LTR=="3LTR" & MyFinal_DB_TableSummary$MySummary2_02_rcYesNo =="sense" & MyFinal_DB_TableSummary$MyIntSiteNotNA==TRUE)
      if ( nrow(MyFinal_DB_TableSummary_current)==0 ) { 
        MyValue <- 0
      } else {
        MyValue <- as.numeric(MyFinal_DB_TableSummary_current$Freq)
      }
      MySummary_08a_3LTRsense_IntSite_nrow <- append(MySummary_08a_3LTRsense_IntSite_nrow,MyValue)
      #MyFinal_DB_TableSummary_3LTRsense_NA 
      MyFinal_DB_TableSummary_current <- subset(MyFinal_DB_TableSummary,MyFinal_DB_TableSummary$MySeqID==unique(MySeqID)[k] & MyFinal_DB_TableSummary$MySummary2_01_5or3LTR=="3LTR" & MyFinal_DB_TableSummary$MySummary2_02_rcYesNo =="sense" & MyFinal_DB_TableSummary$MyIntSiteNotNA==FALSE)
      if ( nrow(MyFinal_DB_TableSummary_current)==0 ) { 
        MyValue <- 0
      } else {
        MyValue <- as.numeric(MyFinal_DB_TableSummary_current$Freq)
      }
      MySummary_08b_3LTRsense_NA_nrow <- append(MySummary_08b_3LTRsense_NA_nrow,MyValue)
      #MyFinal_DB_TableSummary_3LTRantisense 
      MyFinal_DB_TableSummary_current <- subset(MyFinal_DB_TableSummary,MyFinal_DB_TableSummary$MySeqID==unique(MySeqID)[k] & MyFinal_DB_TableSummary$MySummary2_01_5or3LTR=="3LTR" & MyFinal_DB_TableSummary$MySummary2_02_rcYesNo =="antisense" & MyFinal_DB_TableSummary$MyIntSiteNotNA==TRUE)
      if ( nrow(MyFinal_DB_TableSummary_current)==0 ) { 
        MyValue <- 0
      } else {
        MyValue <- as.numeric(MyFinal_DB_TableSummary_current$Freq)
      }
      MySummary_09a_3LTRantisense_IntSite_nrow <- append(MySummary_09a_3LTRantisense_IntSite_nrow,MyValue)
      #MyFinal_DB_TableSummary_3LTRantisense_NA 
      MyFinal_DB_TableSummary_current <- subset(MyFinal_DB_TableSummary,MyFinal_DB_TableSummary$MySeqID==unique(MySeqID)[k] & MyFinal_DB_TableSummary$MySummary2_01_5or3LTR=="3LTR" & MyFinal_DB_TableSummary$MySummary2_02_rcYesNo =="antisense" & MyFinal_DB_TableSummary$MyIntSiteNotNA==FALSE)
      if ( nrow(MyFinal_DB_TableSummary_current)==0 ) { 
        MyValue <- 0
      } else {
        MyValue <- as.numeric(MyFinal_DB_TableSummary_current$Freq)
      }
      MySummary_09b_3LTRantisense_NA_nrow <- append(MySummary_09b_3LTRantisense_NA_nrow,MyValue)
    }
    
    
    MySummary_DF3 <- as.data.frame(cbind(MySummary_06_MySeqID
                                         ,MySummary_06a_5LTRsense_IntSite_nrow
                                         ,MySummary_06b_5LTRsense_NA_nrow
                                         ,MySummary_07a_5LTRantisense_IntSite_nrow
                                         ,MySummary_07b_5LTRantisense_NA_nrow
                                         ,MySummary_08a_3LTRsense_IntSite_nrow
                                         ,MySummary_08b_3LTRsense_NA_nrow
                                         ,MySummary_09a_3LTRantisense_IntSite_nrow
                                         ,MySummary_09b_3LTRantisense_NA_nrow
    ))
    #View(MySummary_DF3)
    write.csv(MySummary_DF3,file=paste(MyOutputDir[o],"Output08_MySummaryDF_IntSiteCount.csv",sep=""),row.names = FALSE)
    
    ########################################
    
    #Unique intsite count analysis
    
    MyFinal_DB_Clean_Analylsis <- subset(MyFinal_DB_Clean,MyFinal_DB_Clean$MyQC=="PassedQC")
    MyFinal_DB_Clean_Analylsis2 <- MyFinal_DB_Clean_Analylsis[,c("MySeqID","My5Verdict","MySummary2_01_5or3LTR")]
    MyFinal_DB_Clean_Analylsis3 <- as.data.frame(table(MyFinal_DB_Clean_Analylsis2))
    MyFinal_DB_Clean_Analylsis3$MySummary2_01_5or3LTR <- as.character(MyFinal_DB_Clean_Analylsis3$MySummary2_01_5or3LTR)
    write.csv(MyFinal_DB_Clean_Analylsis3,file=paste(MyOutputDir[o],"Output09_IntSiteFreqPassedQC.csv",sep=""),row.names = FALSE)
    
    #in excel, manually subset to PassQC and total freq >1 (ie 2 is ok)
    
    ########################################
    
    #Get the top Freq IntSite per sample for quick look of each unique sample
    
    #Step 00.  Setup R
    rm(list= ls()[!(ls() %in% c("StartSysTime","MyFASTQ","MyOutputDir","o"))])
    closeAllConnections() 
    graphics.off() 
    #cat("\014") #send CTRL+L to R, clean console
    #StartSysTime <- Sys.time()
    MyWD <- getwd() #you must have opened this *.R file in RStudio
    setwd(MyWD)
    #library(Biostrings)
    
    #if nothing passed file Output09, skip,
    MyMyInput_DF_09_Length <- nrow(read.csv(paste(MyOutputDir[o],"Output09_IntSiteFreqPassedQC.csv",sep=""),header = TRUE))
    
    if (MyMyInput_DF_09_Length==0){
      print ("No integration sites in Output09 passed QC.")
    } else {
      #Step01.  User settings
      MyInput_DF_09 <- read.csv(paste(MyOutputDir[o],"Output09_IntSiteFreqPassedQC.csv",sep=""),header = TRUE)
      FreqCutoff <- 5
      
      #View(MyInput_DF_09)
      MyInput_DF_09_uniqID <- as.character(unique(MyInput_DF_09$MySeqID))
      MyInput_DF_09_Top <- c()
      MyInput_DF_09_Top_Freq <- c()
      MyInput_DF_09_UniqIntSit_Count <- c()
      for (a in 1:length(MyInput_DF_09_uniqID)){
        MyInput_DF_09_subset <- subset(MyInput_DF_09,MyInput_DF_09$MySeqID==MyInput_DF_09_uniqID[a] & MyInput_DF_09$Freq>=FreqCutoff)
        MyInput_DF_09_UniqIntSit_Count <- append(MyInput_DF_09_UniqIntSit_Count,nrow(MyInput_DF_09_subset))
        if (nrow(MyInput_DF_09_subset)>0){
          MyInput_DF_09_subset_maxfreq <- subset(MyInput_DF_09_subset,MyInput_DF_09_subset$Freq==max(MyInput_DF_09_subset$Freq))
        } else {
          MyInput_DF_09_subset_maxfreq <- MyInput_DF_09_subset
        }
        #View(MyInput_DF_09_subset_maxfreq)
        #MyInput_DF_09_subset_ordered <- MyInput_DF_09_subset[order(-MyInput_DF_09_subset$Freq),]
        if (nrow(MyInput_DF_09_subset_maxfreq)==1){
          MyInput_DF_09_Top <- append(MyInput_DF_09_Top,as.character(MyInput_DF_09_subset_maxfreq$My5Verdict[1]))
          MyInput_DF_09_Top_Freq <- append(MyInput_DF_09_Top_Freq,MyInput_DF_09_subset_maxfreq$Freq[1])
        } else if (nrow(MyInput_DF_09_subset_maxfreq)>1){
          #print(MyInput_DF_09_uniqID[a])
          #print(a)
          MyInput_DF_09_Top_paste <- paste("Tied","nrow",nrow(MyInput_DF_09_subset_maxfreq),"FirstListed",MyInput_DF_09_subset_maxfreq$My5Verdict[1],sep=";")
          MyInput_DF_09_Top <- append(MyInput_DF_09_Top,MyInput_DF_09_Top_paste)
          MyInput_DF_09_Top_Freq <- append(MyInput_DF_09_Top_Freq,MyInput_DF_09_subset_maxfreq$Freq[1])
        } else if (nrow(MyInput_DF_09_subset_maxfreq)==0){
          MyInput_DF_09_Top <- append(MyInput_DF_09_Top,"ZeroNrow")
          MyInput_DF_09_Top_Freq <- append(MyInput_DF_09_Top_Freq,NA)
        } else {
          MyInput_DF_09_Top <- append(MyInput_DF_09_Top,"Check")
          MyInput_DF_09_Top_Freq <- append(MyInput_DF_09_Top_Freq,NA)
        }
        
      }
      
      
      MyTopIntSite_FINAL <- as.data.frame(cbind(
        MyInput_DF_09_uniqID
        ,MyInput_DF_09_Top
        ,MyInput_DF_09_Top_Freq
        ,MyInput_DF_09_UniqIntSit_Count
      ))
      
      write.csv(MyTopIntSite_FINAL,paste(MyOutputDir[o],"Output10_MyTopIntSite_FINAL.csv",sep=""))
      
      
      ###################################
      
      #merge all important summary data#
      
      
      #Step 00.  Setup R
      rm(list= ls()[!(ls() %in% c("StartSysTime","MyFASTQ","MyOutputDir","o"))])
      closeAllConnections() 
      graphics.off() 
      #cat("\014") #send CTRL+L to R, clean console
      #StartSysTime <- Sys.time()
      MyWD <- getwd() #you must have opened this *.R file in RStudio
      setwd(MyWD)
      
      MyInput_DF_01 <- read.csv(paste(MyOutputDir[o],"Output01_MySummaryDF_Count.csv",sep=""),header = TRUE)
      SeqID <- substr(MyInput_DF_01$MySummary_01_FastqName,1,5)
      MyInput_DF_01_SeqID <- as.data.frame(cbind(MyInput_DF_01,SeqID))
      MyInput_DF_08 <- read.csv(paste(MyOutputDir[o],"Output08_MySummaryDF_IntSiteCount.csv",sep=""),header = TRUE)
      MyInput_DF_10 <- read.csv(paste(MyOutputDir[o],"Output10_MyTopIntSite_FINAL.csv",sep=""),header = TRUE)
      
      
      
      MySummaryDB_FINAL <- merge(MyInput_DF_01_SeqID
                                 ,MyInput_DF_08
                                 ,by.x="SeqID"
                                 ,by.y="MySummary_06_MySeqID"
                                 ,all = TRUE
      )
      
      MySummaryDB_FINAL <- merge(MySummaryDB_FINAL
                                 ,MyInput_DF_10
                                 ,by.x="SeqID"
                                 ,by.y="MyInput_DF_09_uniqID"
                                 ,all = TRUE
      )
      
      write.csv(MySummaryDB_FINAL,paste(MyOutputDir[o],"Output11_FINAL_UniqSummary.csv",sep=""))
      
      
      #20200428 Add remove Output09 freq=0
      MyOutput09 <- read.csv(paste(MyOutputDir[o],"Output09_IntSiteFreqPassedQC.csv",sep=""))
      MyOutput09_nozero <- subset(MyOutput09,MyOutput09$Freq!=0)
      MyOutput09_nozero_sorted <- MyOutput09_nozero[order(MyOutput09_nozero$MySeqID,-MyOutput09_nozero$Freq),]
      write.csv(MyOutput09_nozero_sorted,paste(MyOutputDir[o],"Output09b_IntSiteFreqPassedQC_NonZero.csv",sep=""))
    }
    }
}
  
  ########################################
  #Step 03. End
  EndSysTime <- Sys.time()
  print(MyFASTQ[o])
  print(paste("Script started running",StartSysTime))
  print(paste("Script finished running",EndSysTime))
  
  ############ CLEAR EVERYTHING ########
  rm(list= ls()[!(ls() %in% c("StartSysTime","MyFASTQ","MyOutputDir","o"))])
  closeAllConnections() 
  graphics.off() 
  #cat("\014") #send CTRL+L to R, clean console
  #StartSysTime <- Sys.time()
  MyWD <- getwd()
  setwd(MyWD)
  MyBlastnDir <- "/Users/guinmacpro6/"
  MyBlatDir <- "/Users/guinmacpro6/" #change as appropriate, remember permission
  MyBlatMerger_Dir <- "/Users/guinmacpro6/BLATmergerGUIN/"
}

file.rename(from="./Output/",to="./Output_Locked/")

