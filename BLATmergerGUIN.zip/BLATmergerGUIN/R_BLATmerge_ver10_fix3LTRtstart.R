#Objective:  Merge webBLAT psl, output top score
#Input:  BLAT psl or html, saved as tabdelim as any filename in folder "./BLAT_HTML" and "./BLAT_PSL"
#Output:  
#01 Merge csv
#02 Top score
#03 NCBI RefGene List Gene name or multiplematches
#Potential problem: If ties in top score, will take first entry. Therefore, it is important to get at least 2 pieces of evidences.
#Consider: Saving NCBI_RefSeq df as R object

#### Updates ####
#20171212 In cases of MultipleMatches, export all gene names instead of just saying "multiplematch"
#20180215 LENTIX013 qstart=1 screwed up the entire software. remove
#20230824 Add o to do-not-remove-list

#Step 00. Setup R #PC@work R version 3.2.2
rm(list= ls()[!(ls() %in% c("StartSysTime","My5Lenti","My3Lenti","MyFinal_DB","MyBlat_Ouptut_FileName","MyWD","MyBlat_Ouptut_DF2","o"))])
closeAllConnections() 
graphics.off() 
#cat("\014") #send CTRL+L to R, clean console
#StartSysTime <- Sys.time()
MyWD_2 <- getwd()
setwd(MyWD_2)
#library(Biostrings) #PC@work Biostrings_2.38.1
#library(muscle) #PC@work muscle_3.12.0
#library(ape) #conflicts with muscle, don't load both
#library(gdata)
#library(imager)
#sessionInfo()
#EndSysTime <- Sys.time()
#print(paste("Script started running",StartSysTime))
#print(paste("Script finished running",EndSysTime))
# install.packages("refGenome")
# library(refGenome)
# read.gtf(paste("Features/",MyFeatureList[2],sep=""))
# error

unlink("./Output_BLATmerger/",recursive = TRUE)
dir.create("./Output_BLATmerger/")


#BLAT output with merged 5Lenti 3Lenti QSIZE info#
#List files in BLAT_PSL dir#
MyHTMLDF <- MyBlat_Ouptut_DF2
#View(MyHTMLDF)
#write.csv(MyHTMLDF,file="Test_MyHTMLDF.csv")

#20190401 Add STRAND info
print("BLAT merger Step1. Now adding STRAND +/- info")
# STRAND <- c()
# for (i in 1:nrow(MyHTMLDF)){
#   if(MyHTMLDF$TEND[i]>MyHTMLDF$TSTART[i]){
#     STRAND <- append(STRAND,"+")
#   } else if (MyHTMLDF$TEND[i]<MyHTMLDF$TSTART[i]){
#     STRAND <- append(STRAND,"-")
#   } else {
#     STRAND <- append(STRAND,"Error")
#   }
# }
Test1 <- MyHTMLDF$TEND>MyHTMLDF$TSTART #+
Test2 <- MyHTMLDF$TEND<MyHTMLDF$TSTART #-
Test3 <- MyHTMLDF$TEND==MyHTMLDF$TSTART #error
Test4 <- Test1 & !Test2 & !Test3 #+
Test5 <- Test2 & !Test1 & !Test3 #-
Test6 <- which(Test4==TRUE)
Test7 <- c()
Test7[Test6] <- "+"
Test8 <- which(Test5==TRUE)
Test7[Test8] <- "-"
MyHTMLDF <- cbind(MyHTMLDF
                  ,STRAND=Test7)
#View(MyHTMLDF)
write.csv(MyHTMLDF,file="./Output_BLATmerger/02_BLAT_HTML_Concatenate.csv")


#Subset to (1) 5Lenti QEND=QSIZE or (2) 3Lenti QSTART==1, then sort by decending e-value#
print("BLAT merger Step2. Now subsetting for smallest evalue and QEND=QSIZE or QSTART=1")
MyUniqID <- as.character(unique(MyHTMLDF$QUERY))
MyHTMLDF_FINAL <- data.frame()
for (j in 1:length(MyUniqID)){
  if (as.character(subset(MyHTMLDF,MyHTMLDF$QUERY==MyUniqID[j])[1,]$WhichEnd)=="5Lenti"){
    MyHTMLDF_Subset <- subset(MyHTMLDF,MyHTMLDF$QUERY==MyUniqID[j] & MyHTMLDF$QEND==MyHTMLDF$MyBLAT_len) 
    #View(MyHTMLDF_Subset) 
  } else if (as.character(subset(MyHTMLDF,MyHTMLDF$QUERY==MyUniqID[j])[1,]$WhichEnd)=="3Lenti"){
    MyHTMLDF_Subset <- subset(MyHTMLDF,MyHTMLDF$QUERY==MyUniqID[j] & MyHTMLDF$QSTART==1)
  } else {
    MyHTMLDF_Subset <- subset(MyHTMLDF,MyHTMLDF$QUERY==MyUniqID[j])
  }
  MyDecreasingOrder <- order(MyHTMLDF_Subset$EVALUE)
  MyHTMLDF_Subset2 <- MyHTMLDF_Subset[MyDecreasingOrder,]
  if (nrow(MyHTMLDF_Subset2)==0){
    #do nothing
  } else {
    MyHTMLDF_FINAL <- rbind(MyHTMLDF_FINAL,MyHTMLDF_Subset2[1,]) 
  }
}
#HERE 20191225#
My_HTMLOutput_Filename <- "./Output_BLATmerger/02_BLAT_HTML_TopScore.csv"
write.csv(MyHTMLDF_FINAL,file=My_HTMLOutput_Filename)
#View(MyHTMLDF_FINAL)

#Match HTMLoutput to NCBI_RefGenes HG38 Features#
print("BLAT merger Step3. Now matching against NCBI RefSeq (last step)")
MyFeatureList <- list.files(path="./Features")
MyCurrentFeature_DF <- read.delim(paste("Features/",MyFeatureList[1],sep=""))
#View(head(MyCurrentFeature_DF))
#name2
#chrom
#txStart
#txEnd
#View(MyHTMLDF_FINAL)
MyMatchResult_Name <- c()
MyMatchResult_Name2 <- c()
#Loop through every BLAT top score result
for (i in 1:nrow(MyHTMLDF_FINAL)){
  #Step1. Define search coordinates and chr
  MySearch_Coordinate <- if(MyHTMLDF_FINAL[i,"STRAND"]=="+" & MyHTMLDF_FINAL[i,"WhichEnd"]=="5Lenti"){
    MyHTMLDF_FINAL[i,"TEND"]
  } else if (MyHTMLDF_FINAL[i,"STRAND"]=="+" & MyHTMLDF_FINAL[i,"WhichEnd"]=="3Lenti") {
    MyHTMLDF_FINAL[i,"TSTART"]
  } else if (MyHTMLDF_FINAL[i,"STRAND"]=="-" & MyHTMLDF_FINAL[i,"WhichEnd"]=="5Lenti") {
    MyHTMLDF_FINAL[i,"TEND"] 
  } else if (MyHTMLDF_FINAL[i,"STRAND"]=="-" & MyHTMLDF_FINAL[i,"WhichEnd"]=="3Lenti") {
    MyHTMLDF_FINAL[i,"TSTART"]
  }
  MySearch_Chrom <- paste(as.character(MyHTMLDF_FINAL[i,"CHRO"]),sep="")
  #Step2. Search (SUBSET) in Ref database
  MyCurrentFeature_DF_Subset <- subset(MyCurrentFeature_DF,
                                       (MyCurrentFeature_DF$chrom==MySearch_Chrom)
                                       & (MyCurrentFeature_DF$txStart<=MySearch_Coordinate)
                                       & (MyCurrentFeature_DF$txEnd>=MySearch_Coordinate)
  )
  #View(MyCurrentFeature_DF_Subset)
  if(nrow(MyCurrentFeature_DF_Subset)==0){
    MyMatchResult_Name <- append(MyMatchResult_Name,"NoMatch")
    MyMatchResult_Name2 <- append(MyMatchResult_Name2,"NoMatch")
  } else if (nrow(MyCurrentFeature_DF_Subset)==1){
    MyMatchResult_Name <- append(MyMatchResult_Name,as.character(MyCurrentFeature_DF_Subset$name[1]))
    MyMatchResult_Name2 <- append(MyMatchResult_Name2,as.character(MyCurrentFeature_DF_Subset$name2[1]))
  } else if (all(as.character(MyCurrentFeature_DF_Subset$name2) == as.character(MyCurrentFeature_DF_Subset$name2[1]))){
    #If all gene names (name2) are the same, take first row
    MyMatchResult_Name <- append(MyMatchResult_Name,as.character(MyCurrentFeature_DF_Subset$name[1]))
    MyMatchResult_Name2 <- append(MyMatchResult_Name2,as.character(MyCurrentFeature_DF_Subset$name2[1]))
  } else {
    #If there are multiple genes that fall under this coordinate
    MyMatchResult_Name <- append(MyMatchResult_Name,as.character(paste("MultipleMatches;",MyCurrentFeature_DF_Subset$name,sep="",collapse="")))
    MyMatchResult_Name2 <- append(MyMatchResult_Name2,as.character(paste("MultipleMatches;",MyCurrentFeature_DF_Subset$name2,sep="",collapse="")))
    write.csv(MyCurrentFeature_DF_Subset,file=paste("./Output_BLATmerger/MultipleMatches_",as.character(MyHTMLDF_FINAL[i,"QUERY"]),".csv",sep=""))
  }
}
MyHTMLDF_FINAL_Genes <- cbind(MyHTMLDF_FINAL
                              ,MyMatchResult_Name
                              ,MyMatchResult_Name2)
write.csv(MyHTMLDF_FINAL_Genes,file="./Output_BLATmerger/03_BLAT_HTML_TopScore_NCBIRefGenes.csv")

print("BLAT merger run completed")
#View(MyHTMLDF_FINAL_Genes)
