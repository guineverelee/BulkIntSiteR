###############################################################
# Step 00 — Clean environment
###############################################################
rm(list = ls())
closeAllConnections()
graphics.off()
cat("\014")   # Clear console

###############################################################
# Step 01 — Setup & Libraries
###############################################################
ProjDir <- '/Users/virender/Dropbox @RU Dropbox/Virender Pal/Guin-Virender/Method_paper_draft/PRISM-seq_paper/Final_Documentation_Readme/Filter_script'
setwd(ProjDir)

library(tidyverse)
library(dplyr)

###############################################################
# Step 02 — Load Input Files
###############################################################
IS_5LTR <- read.csv("5LTR_2_Output09b_IntSiteFreqPassedQC_NonZero.csv",
                    stringsAsFactors = FALSE)

IS_3LTR <- read.csv("3LTR_2_Output09b_IntSiteFreqPassedQC_NonZero.csv",
                    stringsAsFactors = FALSE)

###############################################################
# Step 03 — Filter to keep only correct LTR type
###############################################################
IS_5LTR <- filter(IS_5LTR, MySummary2_01_5or3LTR == "5LTR")
IS_3LTR <- filter(IS_3LTR, MySummary2_01_5or3LTR == "3LTR")

###############################################################
# Step 04 — Helper: Clean MySeqID + Expand My5Verdict → 4 columns
###############################################################
fix_columns <- function(df) {
  
  # Clean MySeqID of leading index numbers
  df$MySeqID <- sub("^\\s*\\d+\\s+", "", as.character(df$MySeqID))
  
  # Split MySeqID (retain first chunk only)
  df <- df %>%
    separate(MySeqID, into = c("MySeqID_clean", "rest"), sep = "_",
             remove = FALSE, fill = "right", extra = "drop") %>%
    select(-rest)
  
  # Split My5Verdict into 6 columns
  tmp <- tidyr::separate(df,
                         col = My5Verdict,
                         into = paste0("Col", 1:6),
                         sep = "_",
                         fill = "right",
                         extra = "merge",
                         remove = FALSE)
  
  # Apply correction logic
  tmp$Col2 <- ifelse(tmp$Col1 == "chrUn", tmp$Col3, tmp$Col2)
  tmp$Col3 <- ifelse(tmp$Col1 == "chrUn", tmp$Col4, tmp$Col3)
  tmp$Col4 <- ifelse(tmp$Col1 == "chrUn", tmp$Col5, tmp$Col4)
  
  tmp$Col2 <- ifelse(substr(tmp$Col2, 1, 1) %in% c("G","K","J"), tmp$Col4, tmp$Col2)
  tmp$Col3 <- ifelse(tmp$Col3 %in% c("alt","random"), tmp$Col5, tmp$Col3)
  tmp$Col4 <- ifelse(grepl("^\\d+$", tmp$Col4), tmp$Col6, tmp$Col4)
  
  # Keep ONLY the cleaned 4 output columns
  cleaned <- tmp %>%
    transmute(
      chromfixed  = Col1,
      coordfixed  = Col2,
      strandfixed = Col3,
      genefixed   = Col4
    )
  
  # Bind cleaned columns
  df <- cbind(df, cleaned)
  
  return(df)
}


###############################################################
# Step 05 — Apply transformation to both datasets
###############################################################
IS_5LTR <- fix_columns(IS_5LTR)
IS_3LTR <- fix_columns(IS_3LTR)

###############################################################
# Step 06 — Basic sanity check
###############################################################
cat("5LTR rows:", nrow(IS_5LTR), "\n")
cat("3LTR rows:", nrow(IS_3LTR), "\n")


##### below is the filter steps####
#2. Second selection to merge My5Verdict in 10bp of range.
# Initialize an empty list to store results
pooled_data_list <- list()

# Iterate through each unique MySeqID
unique_MySeqIDs <- unique(IS_5LTR$MySeqID)

for (seq_id in unique_MySeqIDs) {
  # Subset the data for the current MySeqID
  subset_data <- IS_5LTR %>% filter(MySeqID == seq_id)
  
  # Initialize an empty dataframe to store the pooled data for the current MySeqID
  pooled_data_single <- data.frame()
  
  # Iterate through each unique gene in the subset data
  unique_genes <- unique(subset_data$genefixed)
  for (gene in unique_genes) {
    # Subset the data for the current gene
    subset_gene_data <- subset_data %>% filter(genefixed == gene)
    
    # Convert coordfixed to numeric and remove non-numeric values
    subset_gene_data <- subset_gene_data %>%
      mutate(coordfixed = as.numeric(as.character(coordfixed))) %>%
      filter(!is.na(coordfixed))
    
    # Sort the subset data by coordfixed
    subset_gene_data <- subset_gene_data[order(subset_gene_data$coordfixed), ]
    
    # Check if there are at least two rows for comparison
    if (nrow(subset_gene_data) >= 2) {
      # Iterate through each row of the subset data
      for (i in 1:(nrow(subset_gene_data) - 1)) {
        # Check if both current and next row have non-missing values in genefixed column
        if (!is.na(subset_gene_data$genefixed[i]) && !is.na(subset_gene_data$genefixed[i + 1])) {
          # Check if the current and next row have similar gene name
          if (subset_gene_data$genefixed[i] == subset_gene_data$genefixed[i + 1]) {
            # Check if the coordinates are within +/- 10 range
            if (abs(subset_gene_data$coordfixed[i] - subset_gene_data$coordfixed[i + 1]) <= 10) {
              # Keep the row with the higher Freq value
              if (subset_gene_data$Freq[i] >= subset_gene_data$Freq[i + 1]) {
                subset_gene_data <- subset_gene_data[-(i + 1), ]
              } else {
                subset_gene_data <- subset_gene_data[-i, ]
              }
            }
          }
        }
      }
    }
    
    # Append the processed subset data to the pooled data for the current MySeqID
    pooled_data_single <- rbind(pooled_data_single, subset_gene_data)
  }
  
  # Append the pooled data for the current MySeqID to the list
  pooled_data_list[[seq_id]] <- pooled_data_single
}

# Combine results from the list into a single dataframe
pooled_data_5LTR <- bind_rows(pooled_data_list)

#3. Third selection to remove same gene when present in same well of expanded gene clone
# Initialize an empty list to store results
final_pooled_data_list <- list()

# Initialize an empty dataframe to store rows with "NoMatch" in genefixed column
NoMatch_rows <- data.frame()

# Iterate through each unique gene
unique_genes <- unique(pooled_data_5LTR$genefixed)

for (gene in unique_genes) {
  # Exclude "NoMatch"
  if (gene != "NoMatch") {
    # Subset the data for the current gene
    subset_gene_data <- pooled_data_5LTR %>% filter(genefixed == gene)
    
    # Get unique MySeqID values for the current gene
    unique_MySeqIDs <- unique(subset_gene_data$MySeqID)
    
    # Iterate through each unique MySeqID
    for (seq_id in unique_MySeqIDs) {
      # Subset the data for the current MySeqID
      subset_seq_data <- subset_gene_data %>% filter(MySeqID == seq_id)
      
      # Keep the row with the highest frequency for the current MySeqID
      subset_seq_data <- subset_seq_data[which.max(subset_seq_data$Freq), ]
      
      # Append the processed subset data to the final pooled data list
      final_pooled_data_list[[length(final_pooled_data_list) + 1]] <- subset_seq_data
    }
  } else {
    # Extract rows with "NoMatch" in genefixed column
    NoMatch_rows <- rbind(NoMatch_rows, pooled_data_5LTR %>% filter(genefixed == gene))
  }
}

# Combine results from the list into a single dataframe
final_pooled_data_5LTR <- bind_rows(final_pooled_data_list)

# Append rows with "NoMatch" in genefixed column to final_pooled_data
final_pooled_data_5LTR <- rbind(final_pooled_data_5LTR, NoMatch_rows)

##############repeat the 10bp and gene collapse for 3LTR###################
#2. Second selection to merge My5Verdict in 10bp of range.
# Initialize an empty list to store results
pooled_data_list <- list()

# Iterate through each unique MySeqID
unique_MySeqIDs <- unique(IS_3LTR$MySeqID)

for (seq_id in unique_MySeqIDs) {
  # Subset the data for the current MySeqID
  subset_data <- IS_3LTR %>% filter(MySeqID == seq_id)
  
  # Initialize an empty dataframe to store the pooled data for the current MySeqID
  pooled_data_single <- data.frame()
  
  # Iterate through each unique gene in the subset data
  unique_genes <- unique(subset_data$genefixed)
  for (gene in unique_genes) {
    # Subset the data for the current gene
    subset_gene_data <- subset_data %>% filter(genefixed == gene)
    
    # Convert coordfixed to numeric and remove non-numeric values
    subset_gene_data <- subset_gene_data %>%
      mutate(coordfixed = as.numeric(as.character(coordfixed))) %>%
      filter(!is.na(coordfixed))
    
    # Sort the subset data by coordfixed
    subset_gene_data <- subset_gene_data[order(subset_gene_data$coordfixed), ]
    
    # Check if there are at least two rows for comparison
    if (nrow(subset_gene_data) >= 2) {
      # Iterate through each row of the subset data
      for (i in 1:(nrow(subset_gene_data) - 1)) {
        # Check if both current and next row have non-missing values in genefixed column
        if (!is.na(subset_gene_data$genefixed[i]) && !is.na(subset_gene_data$genefixed[i + 1])) {
          # Check if the current and next row have similar gene name
          if (subset_gene_data$genefixed[i] == subset_gene_data$genefixed[i + 1]) {
            # Check if the coordinates are within +/- 10 range
            if (abs(subset_gene_data$coordfixed[i] - subset_gene_data$coordfixed[i + 1]) <= 10) {
              # Keep the row with the higher Freq value
              if (subset_gene_data$Freq[i] >= subset_gene_data$Freq[i + 1]) {
                subset_gene_data <- subset_gene_data[-(i + 1), ]
              } else {
                subset_gene_data <- subset_gene_data[-i, ]
              }
            }
          }
        }
      }
    }
    
    # Append the processed subset data to the pooled data for the current MySeqID
    pooled_data_single <- rbind(pooled_data_single, subset_gene_data)
  }
  
  # Append the pooled data for the current MySeqID to the list
  pooled_data_list[[seq_id]] <- pooled_data_single
}

# Combine results from the list into a single dataframe
pooled_data_3LTR <- bind_rows(pooled_data_list)

#3. Third selection to remove same gene when present in same well of expanded gene clone
# Initialize an empty list to store results
final_pooled_data_list <- list()

# Initialize an empty dataframe to store rows with "NoMatch" in genefixed column
NoMatch_rows <- data.frame()

# Iterate through each unique gene
unique_genes <- unique(pooled_data_3LTR$genefixed)

for (gene in unique_genes) {
  # Exclude "NoMatch"
  if (gene != "NoMatch") {
    # Subset the data for the current gene
    subset_gene_data <- pooled_data_3LTR %>% filter(genefixed == gene)
    
    # Get unique MySeqID values for the current gene
    unique_MySeqIDs <- unique(subset_gene_data$MySeqID)
    
    # Iterate through each unique MySeqID
    for (seq_id in unique_MySeqIDs) {
      # Subset the data for the current MySeqID
      subset_seq_data <- subset_gene_data %>% filter(MySeqID == seq_id)
      
      # Keep the row with the highest frequency for the current MySeqID
      subset_seq_data <- subset_seq_data[which.max(subset_seq_data$Freq), ]
      
      # Append the processed subset data to the final pooled data list
      final_pooled_data_list[[length(final_pooled_data_list) + 1]] <- subset_seq_data
    }
  } else {
    # Extract rows with "NoMatch" in genefixed column
    NoMatch_rows <- rbind(NoMatch_rows, pooled_data_3LTR %>% filter(genefixed == gene))
  }
}

# Combine results from the list into a single dataframe
final_pooled_data_3LTR <- bind_rows(final_pooled_data_list)

# Append rows with "NoMatch" in genefixed column to final_pooled_data
final_pooled_data_3LTR <- rbind(final_pooled_data_3LTR, NoMatch_rows)

#clean the by keeping necessary columns
final_pooled_data_5LTR <- final_pooled_data_5LTR 
  #select(-V1)

final_pooled_data_3LTR <- final_pooled_data_3LTR 
  #select(-V1)

#4. Create a list of final unique integration sites
# Summarize data by unique values in "My5Verdict" for 5LTR

# helper to take first non-NA (for summarise)
safe_first <- function(x) {
  xo <- na.omit(x)
  if (length(xo) == 0) NA else xo[1]
}

# ---- 5' summary ----
unique_IS_5LTR <- final_pooled_data_5LTR %>%
  group_by(MySummary2_01_5or3LTR, My5Verdict) %>%
  summarise(
    Wells = n_distinct(MySeqID),
    Freq  = sum(Freq, na.rm = TRUE),
    chromfixed  = as.character(safe_first(chromfixed)),
    coordfixed  = safe_first(coordfixed),
    strandfixed = safe_first(strandfixed),   # NOTE: your column is 'standfixed', keep as requested name 'strandfixed'
    genefixed   = safe_first(genefixed),
    .groups = "drop"
  )

# ---- 3' summary ----
unique_IS_3LTR <- final_pooled_data_3LTR %>%
  group_by(MySummary2_01_5or3LTR, My5Verdict) %>%
  summarise(
    Wells = n_distinct(MySeqID),
    Freq  = sum(Freq, na.rm = TRUE),
    chromfixed  = as.character(safe_first(chromfixed)),
    coordfixed  = safe_first(coordfixed),
    strandfixed = safe_first(strandfixed),
    genefixed   = safe_first(genefixed),
    .groups = "drop"
  )

# ---- common verdicts (handle empty cases safely) ----
v5 <- if (nrow(unique_IS_5LTR) > 0) unique_IS_5LTR$My5Verdict else character(0)
v3 <- if (nrow(unique_IS_3LTR) > 0) unique_IS_3LTR$My5Verdict else character(0)
common_My5Verdict <- intersect(v5, v3)

# Build common_IS_5and3LTR (empty tibble if no overlap)
if (length(common_My5Verdict) == 0) {
  common_IS_5and3LTR <- tibble(
    My5Verdict = character(0),
    MySummary2_01_5or3LTR = character(0),
    Wells = integer(0),
    Freq  = numeric(0)
  )
} else {
  common_IS_5and3LTR <- lapply(common_My5Verdict, function(v) {
    row_5 <- dplyr::filter(unique_IS_5LTR, My5Verdict == v)
    row_3 <- dplyr::filter(unique_IS_3LTR, My5Verdict == v)
    
    total_wells <- max(c(row_5$Wells, row_3$Wells), na.rm = TRUE)
    total_freq  <- sum(c(row_5$Freq, row_3$Freq), na.rm = TRUE)
    
    summary_5 <- if (nrow(row_5)) paste(unique(row_5$MySummary2_01_5or3LTR), collapse = ",") else ""
    summary_3 <- if (nrow(row_3)) paste(unique(row_3$MySummary2_01_5or3LTR), collapse = ",") else ""
    combined_summary <- paste0(summary_5, "_", summary_3)
    
    tibble(
      My5Verdict = v,
      MySummary2_01_5or3LTR = combined_summary,
      Wells = total_wells,
      Freq  = total_freq
    )
  }) %>% bind_rows()
}

# Normalize columns order
common_IS_5and3LTR <- common_IS_5and3LTR %>%
  select(My5Verdict, MySummary2_01_5or3LTR, Wells, Freq)

# ================= INDIVIDUAL (non-common) BRANCHES =================

# --- 5' LTR branch with sanity check ---
common_vals <- tryCatch({
  if (exists("common_IS_5and3LTR") &&
      is.data.frame(common_IS_5and3LTR) &&
      "My5Verdict" %in% names(common_IS_5and3LTR)) {
    na.omit(unique(common_IS_5and3LTR$My5Verdict))
  } else {
    character(0)
  }
}, error = function(e) character(0))

IS_5LTR_only <- if (length(common_vals) == 0) {
  final_pooled_data_5LTR
} else {
  final_pooled_data_5LTR %>%
    dplyr::filter(!My5Verdict %in% common_vals)
}

IS_5LTR_only <- IS_5LTR_only %>% filter(Freq > 10)

unique_IS_5LTR_only <- IS_5LTR_only %>%
  group_by(My5Verdict, MySummary2_01_5or3LTR) %>%
  summarise(
    Wells = n_distinct(MySeqID),
    Freq  = sum(Freq, na.rm = TRUE),
    .groups = "drop"
  )

# --- 3' LTR branch with sanity check ---
common_vals <- tryCatch({
  if (exists("common_IS_5and3LTR") &&
      is.data.frame(common_IS_5and3LTR) &&
      "My5Verdict" %in% names(common_IS_5and3LTR)) {
    na.omit(unique(common_IS_5and3LTR$My5Verdict))
  } else {
    character(0)
  }
}, error = function(e) character(0))


IS_3LTR_only <- if (length(common_vals) == 0) {
  final_pooled_data_3LTR
} else {
  final_pooled_data_3LTR %>%
    dplyr::filter(!My5Verdict %in% common_vals)
}


# Select rows in IS_5LTR_only where the value in the column "Freq" is more than 10
IS_3LTR_only <- IS_3LTR_only %>%
  filter(Freq > 10)

# Summarize data by unique values in "My5Verdict" for 3LTR
unique_IS_3LTR_only <- IS_3LTR_only %>%
  group_by(My5Verdict, MySummary2_01_5or3LTR) %>%
  summarise(Wells = n_distinct(MySeqID),
            Freq = sum(Freq)
  )


# Combine rows from common_IS_5and3LTR, unique_IS_5LTR_only, and unique_IS_3LTR_only

# --- Ensure each piece exists and has the same columns ---
empty_u <- tibble::tibble(
  My5Verdict = character(),
  MySummary2_01_5or3LTR = character(),
  Wells = integer(),
  Freq  = numeric()
)

if (!exists("common_IS_5and3LTR") || !is.data.frame(common_IS_5and3LTR)) {
  common_IS_5and3LTR <- empty_u
}
if (!exists("unique_IS_5LTR_only") || !is.data.frame(unique_IS_5LTR_only)) {
  unique_IS_5LTR_only <- empty_u
}
if (!exists("unique_IS_3LTR_only") || !is.data.frame(unique_IS_3LTR_only)) {
  unique_IS_3LTR_only <- empty_u
}

normalize_u <- function(df) {
  df %>%
    dplyr::select(My5Verdict, MySummary2_01_5or3LTR, Wells, Freq) %>%
    mutate(
      Wells = as.integer(Wells),
      Freq  = as.numeric(Freq)
    )
}

# --- Now safely combine ---
Final_UIS <- dplyr::bind_rows(
  normalize_u(common_IS_5and3LTR),
  normalize_u(unique_IS_5LTR_only),
  normalize_u(unique_IS_3LTR_only)
)


#write.csv(Final_UIS, "Final_UIS.csv")

# Convert the "Wells" and "Freq" column to numeric
Final_UIS <- Final_UIS %>%
  mutate(Wells = as.numeric(Wells)) %>%
  mutate(Freq = as.numeric(Freq)) %>%
  arrange(desc(Freq))


#### Load sequence data ####
sequence_data <- read.csv("merged_Output07b_MyFinalDB_WithIntSiteOnly.csv.csv")

# Helper: collapse any list-columns to strings before CSV write
collapse_list_col <- function(col) {
  if (is.list(col)) {
    vapply(col, function(x) {
      if (is.null(x) || length(x) == 0) return(NA_character_)
      paste0(as.character(x), collapse = ";")
    }, character(1))
  } else col
}

# Pick one read per verdict for a target LTR ("5LTR" or "3LTR"):
# - include verdicts where Final_UIS$MySummary2_01_5or3LTR is that LTR or "5LTR_3LTR"
# - filter sequence_data to PassedQC + matching LTR
# - prefer read1, fallback to read2 based on MySummary2_00_ReadName last "_" token
pick_reads_for_ltr <- function(final_df, seq_df, target_ltr) {
  # Which verdicts belong in this alignment?
  keep_verdicts <- final_df %>%
    dplyr::filter(MySummary2_01_5or3LTR %in% c(target_ltr, "5LTR_3LTR")) %>%
    dplyr::pull(My5Verdict) %>%
    unique()
  
  if (length(keep_verdicts) == 0) {
    warning(sprintf("No My5Verdict entries mapped to %s in Final_UIS.", target_ltr))
    return(tibble::tibble())
  }
  
  # Ensure required columns exist
  need_cols <- c("My5Verdict","MyQC","MySummary2_07_ToBLAT","MySummary2_00_ReadName","MySummary2_01_5or3LTR")
  if (!all(need_cols %in% names(seq_df))) {
    stop("sequence_data is missing one of: ", paste(need_cols, collapse=", "))
  }
  
  # Candidates: matching verdicts, PassedQC, correct LTR
  candidates <- seq_df %>%
    dplyr::filter(My5Verdict %in% keep_verdicts,
                  MyQC == "PassedQC",
                  MySummary2_01_5or3LTR == target_ltr) %>%
    dplyr::mutate(
      ReadNameLast = vapply(strsplit(MySummary2_00_ReadName, "_", fixed = TRUE),
                            function(v) if (length(v)==0) NA_character_ else trimws(tail(v,1)),
                            character(1)),
      rank = dplyr::case_when(
        grepl("^1", ReadNameLast) ~ 1L,  # read1 preferred
        grepl("^2", ReadNameLast) ~ 2L,  # fallback to read2
        TRUE ~ NA_integer_
      )
    ) %>%
    dplyr::filter(!is.na(rank))
  
  if (nrow(candidates) == 0) {
    warning(sprintf("No PassedQC R1/R2 sequences found for %s.", target_ltr))
    return(tibble::tibble())
  }
  
  # One sequence per verdict: take best rank (R1 then R2)
  selected <- candidates %>%
    dplyr::group_by(My5Verdict) %>%
    dplyr::arrange(rank, .by_group = TRUE) %>%
    dplyr::slice_head(n = 1) %>%
    dplyr::ungroup() %>%
    dplyr::transmute(
      My5Verdict,
      seq = MySummary2_07_ToBLAT,
      MySummary2_00_ReadName,
      ReadChoice = ifelse(rank == 1L, "R1", "R2")
    )
  
  # Warn about verdicts with no usable R1/R2
  dropped <- setdiff(keep_verdicts, selected$My5Verdict)
  if (length(dropped) > 0) {
    warning(sprintf("(%s) Dropped %d verdict(s) with no PassedQC R1/R2: %s",
                    target_ltr, length(dropped), paste(dropped, collapse=", ")))
  }
  
  selected
}

# Write alignment FASTA + provenance CSV.
# Header shows "My5Verdict" and, if available in Final_UIS, appends "|Reads=<Freq>".
write_alignment <- function(selected_df, header_map,
                            fasta_path = "alignment.fasta",
                            csv_path   = "alignment_meta.csv") {
  # Join any extra header info (like Freq)
  sel2 <- selected_df %>%
    dplyr::left_join(header_map, by = "My5Verdict")
  
  # Keep only rows that actually have sequence
  sel2 <- sel2 %>%
    dplyr::filter(!is.na(seq), nzchar(seq))
  
  if (nrow(sel2) == 0) {
    warning(sprintf("No sequences to write for %s; skipping.", fasta_path))
    return(invisible(NULL))
  }
  
  # Build header names (Freq optional)
  header_names <- ifelse(
    is.na(sel2$Freq),
    sel2$My5Verdict,
    paste0(sel2$My5Verdict, "|Reads=", formatC(sel2$Freq, format = "fg", digits = 6))
  )
  
  # Ensure 1:1 with sequences and make them unique
  header_names <- make.unique(as.character(header_names), sep = "_")
  
  # Optional: provenance CSV (comment out if you don't want files)
  out_df <- sel2 %>%
    dplyr::mutate(HeaderUsed = header_names) %>%
    dplyr::select(My5Verdict, HeaderUsed, Freq, seq, MySummary2_00_ReadName, ReadChoice)
  
  # If you do NOT want a CSV, comment the next two lines:
  # out_df <- as.data.frame(lapply(out_df, collapse_list_col), stringsAsFactors = FALSE)
  # utils::write.csv(out_df, csv_path, row.names = FALSE)
  
  # Construct DNAStringSet
  seqs <- Biostrings::DNAStringSet(sel2$seq)
  # Always set names on the sequences themselves (not on aln later)
  names(seqs) <- header_names
  
  # Align if 2+ sequences; else pass through
  if (length(seqs) >= 2) {
    aln <- muscle::muscle(seqs)
    # Convert to XStringSet, then set names from the original sequences
    aln_x <- as(aln, "XStringSet")
    names(aln_x) <- names(seqs)
  } else {
    aln_x <- seqs
  }
  
  # Write FASTA
  Biostrings::writeXStringSet(aln_x, fasta_path)
  cat(sprintf("Wrote %s with %d sequences\n", fasta_path, length(aln_x)))
}

#### Run: build both alignments ####
sel_5 <- pick_reads_for_ltr(Final_UIS, sequence_data, "5LTR")
sel_3 <- pick_reads_for_ltr(Final_UIS, sequence_data, "3LTR")

write_alignment(sel_5, Final_UIS,
                fasta_path = "5LTR_alignment_result_allUIS.fasta",
                csv_path   = "UIS_reads_5LTR.csv")

write_alignment(sel_3, Final_UIS,
                fasta_path = "3LTR_alignment_result_allUIS.fasta",
                csv_path   = "UIS_reads_3LTR.csv")


#Split My5Verdict column by "_" and store in IS_cordfixed
IS_coordfixed <- Final_UIS %>%
  separate(My5Verdict, into = c("Column1", "Column2", "Column3", "Column4", "Column5", "Column6"), sep = "_")


# Check if Column1 starts with "chrUn", replace column 2 value with column3 with corresponding value in Column4
IS_coordfixed$Column2 <- ifelse(IS_coordfixed$Column1 == "chrUn",
                                IS_coordfixed$Column3,
                                IS_coordfixed$Column2)

IS_coordfixed$Column3 <- ifelse(IS_coordfixed$Column1 == "chrUn",
                                IS_coordfixed$Column4,
                                IS_coordfixed$Column3)

IS_coordfixed$Column4 <- ifelse(IS_coordfixed$Column1 == "chrUn",
                                IS_coordfixed$Column5,
                                IS_coordfixed$Column4)


# Check if Column2 starts with "G", "K", or "J", replace with corresponding value in Column4
IS_coordfixed$Column2 <- ifelse(substr(IS_coordfixed$Column2, 1, 1) %in% c("G", "K", "J"),
                                IS_coordfixed$Column4,
                                IS_coordfixed$Column2)

# Check if Column3 is "alt" or "random", replace with corresponding value in Column5
IS_coordfixed$Column3 <- ifelse(IS_coordfixed$Column3 %in% c("alt", "random"),
                                IS_coordfixed$Column5,
                                IS_coordfixed$Column3)

# Check if Column4 is numeric, replace with corresponding value in Column6
IS_coordfixed$Column4 <- ifelse(!grepl("^\\d+$", as.character(IS_coordfixed$Column4)),
                                IS_coordfixed$Column4,
                                IS_coordfixed$Column6)


# Take required columns from IS_cordfixed and rename the columns
columns_to_combine <- IS_coordfixed[, c("Column1", "Column2", "Column3", "Column4")]
colnames(columns_to_combine) <- c("chromfixed", "coordfixed", "standfixed", "genefixed")

# Combine with IS_Data1
totalIS_coordfixed <- cbind(Final_UIS, columns_to_combine)

# output final list of integration sites which need manual correction of non-genic repeat regions#
write.csv(totalIS_coordfixed, "Final_UIS_NoMatch_corrected.csv", row.names = FALSE)













